// btn on click window scroll on next section
const scrollToNextSection = () => {
  const element = document.getElementById("best-seller");
  element.scrollIntoView({behavior: "smooth",});
}

// best seller section swiper slider
 var productslider = new Swiper('.sellerSlider', {
  slidesPerView: 'auto',
  freeMode: true,
  spaceBetween:30,
  mousewheel: {
    forceToAxis: true,
  },
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
});

// image parallax script
const elements = document.querySelectorAll('.parallax-element');
const updatePosition = () => {
  elements.forEach(element => {
    const scrollRatio = window.pageYOffset * element.dataset.ratio;
    element.style.transform = ` translate(0, ${-scrollRatio}px)`;
  }); 
};
updatePosition();
document.addEventListener('scroll', () => {
  const ScrollY = window.scrollY + window.innerHeight;
  const offsetY = document.querySelector('.parallax-banner').getBoundingClientRect().top + window.scrollY;
  if (ScrollY >= offsetY) updatePosition();
});

